#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char str[] = "Beautiful";
    int j = 0;
    for (int i = 0; str[i] != '\0'; i++) {
        if (!(strchr("AEIOUaeiou", str[i]))) str[j++] = str[i];
    }
    str[j] = '\0';
    cout << str;
    return 0;
}
