#include <iostream>
using namespace std;

int main()
{
int rows,cols;
cout<<"enter rows:\n";
cin>>rows;


cout<<"enter columns:\n";
cin>>cols;

int arr[100][100];
cout<<"enter the elements:\n";
for(int i=0;i<rows;i++){
    for(int j=0;j<cols;j++){
        cin>>arr[i][j];
    }
}

cout<<"transpose of the matrix is:\n";
for(int i=0;i<cols;i++){
    for(int j=0;j<rows;j++){
        cout<<arr[j][i] << "";
    }
    cout<<endl;
}

    return 0;
}