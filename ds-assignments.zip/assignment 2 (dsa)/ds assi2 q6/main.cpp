#include <iostream>
using namespace std;

#define MAX 100

// Triplet representation of Sparse Matrix
struct Sparse {
    int row, col, val;
};

void printSparse(Sparse a[]) {
    for (int i = 0; i <= a[0].val; i++)
        cout << a[i].row << " " << a[i].col << " " << a[i].val << endl;
}

// (a) Transpose
void transpose(Sparse a[], Sparse b[]) {
    int n = a[0].val, k = 1;
    b[0].row = a[0].col;
    b[0].col = a[0].row;
    b[0].val = n;
    for (int i = 0; i < a[0].col; i++) {
        for (int j = 1; j <= n; j++) {
            if (a[j].col == i) {
                b[k].row = a[j].col;
                b[k].col = a[j].row;
                b[k].val = a[j].val;
                k++;
            }
        }
    }
}

// (b) Addition
void addSparse(Sparse a[], Sparse b[], Sparse c[]) {
    if (a[0].row != b[0].row || a[0].col != b[0].col) {
        cout << "Addition not possible\n";
        return;
    }
    int i = 1, j = 1, k = 1;
    c[0].row = a[0].row;
    c[0].col = a[0].col;
    while (i <= a[0].val && j <= b[0].val) {
        if (a[i].row < b[j].row || (a[i].row == b[j].row && a[i].col < b[j].col))
            c[k++] = a[i++];
        else if (b[j].row < a[i].row || (b[j].row == a[i].row && b[j].col < a[i].col))
            c[k++] = b[j++];
        else {
            c[k].row = a[i].row;
            c[k].col = a[i].col;
            c[k].val = a[i].val + b[j].val;
            k++; i++; j++;
        }
    }
    while (i <= a[0].val) c[k++] = a[i++];
    while (j <= b[0].val) c[k++] = b[j++];
    c[0].val = k - 1;
}

// (c) Multiplication
void multiplySparse(Sparse a[], Sparse b[], Sparse c[]) {
    if (a[0].col != b[0].row) {
        cout << "Multiplication not possible\n";
        return;
    }
    Sparse bt[MAX];
    transpose(b, bt);
    int k = 1;
    c[0].row = a[0].row;
    c[0].col = b[0].col;
    for (int i = 1; i <= a[0].val;) {
        int r = a[i].row;
        for (int j = 1; j <= bt[0].val;) {
            int col = bt[j].row, sum = 0;
            int ti = i, tj = j;
            while (ti <= a[0].val && a[ti].row == r &&
                   tj <= bt[0].val && bt[tj].row == col) {
                if (a[ti].col < bt[tj].col) ti++;
                else if (a[ti].col > bt[tj].col) tj++;
                else sum += a[ti++].val * bt[tj++].val;
            }
            if (sum != 0) {
                c[k].row = r;
                c[k].col = col;
                c[k].val = sum;
                k++;
            }
            while (tj <= bt[0].val && bt[tj].row == col) tj++;
        }
        while (i <= a[0].val && a[i].row == r) i++;
    }
    c[0].val = k - 1;
}

int main() {
    // Example Sparse Matrix A
    Sparse A[MAX] = {{3, 3, 3}, {0, 0, 1}, {0, 2, 2}, {1, 1, 3}};
    Sparse B[MAX] = {{3, 3, 2}, {0, 1, 4}, {1, 2, 5}};
    Sparse C[MAX], D[MAX];

    cout << "Matrix A:\n"; printSparse(A);
    cout << "\nMatrix B:\n"; printSparse(B);

    cout << "\n(a) Transpose of A:\n";
    transpose(A, C); printSparse(C);

    cout << "\n(b) A + B:\n";
    addSparse(A, B, D); printSparse(D);

    cout << "\n(c) A * B:\n";
    multiplySparse(A, B, C); printSparse(C);

    return 0;
}
