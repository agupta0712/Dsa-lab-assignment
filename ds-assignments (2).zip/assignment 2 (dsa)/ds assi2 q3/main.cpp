#include <iostream>
using namespace std;

int findMissing(int arr[], int n) {
    int first = arr[0], last = arr[n - 1];
    int expectedSum = (n + 1) * (first + last) / 2;
    int actualSum = 0;
    for (int i = 0; i < n; i++) actualSum += arr[i];
    return expectedSum - actualSum;
}

int main() {
    int arr[] = {1, 2, 3, 5, 6, 7}; 
    int n = sizeof(arr) / sizeof(arr[0]);
    cout << "Missing Number: " << findMissing(arr, n);
    return 0;
}
