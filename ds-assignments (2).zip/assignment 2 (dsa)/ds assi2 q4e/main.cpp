#include <iostream>
using namespace std;

int main() {
    char ch = 'A';
    ch = tolower(ch);
    cout << ch;
    return 0;
}
