#include <iostream>
#include <vector>
using namespace std;

void improvedSelectionSort(vector<int>& arr) {
    int n = arr.size();
    int start = 0, end = n - 1;
    while (start < end) {
        int min_idx = start, max_idx = start;
        for (int i = start; i <= end; i++) {
            if (arr[i] < arr[min_idx]) min_idx = i;
            if (arr[i] > arr[max_idx]) max_idx = i;
        }
        swap(arr[start], arr[min_idx]);
        if (max_idx == start) max_idx = min_idx;
        swap(arr[end], arr[max_idx]);
        start++;
        end--;
    }
}

int main() {
    vector<int> arr = {64, 25, 12, 22, 11, 90, 34};
    improvedSelectionSort(arr);
    for (int x : arr) cout << x << " ";
    return 0;
}
