#include <iostream>
using namespace std;

int main()
{
int rows,col;

cout<<"enter rows";
cin>>rows;

cout<<"enter cols";
cin>>col;

int arr[100][100];
cout<<"enter the elements:\n";
for(int i=0;i<rows;i++){
    for(int j=0;j<col;j++){
        cin>>arr[i][j];
    }
}

cout<<"sum of each row is:\n";

for(int i=0;i<rows;i++){
    int rowSum=0;

    for(int j=0;j<col;j++){
        rowSum+=arr[i][j];
    }
        cout<<"row" <<i+1 <<" sum= "<<rowSum<<endl;

}



cout<<"sum of each column is:\n";

for(int j=0;j<col;j++){
    int colSum=0;

    for(int i=0;i<rows;i++){
        colSum+=arr[i][j];
    }
    
    cout<<"column "<<j+1 <<" sum= "<<colSum<<endl;
}



    return 0;
}