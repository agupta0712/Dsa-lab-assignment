#include <iostream>
#define MAX_SIZE 5 

class Queue {
private:
    int arr[MAX_SIZE];
    int front;
    int rear;

public:
    Queue() {
        front = -1;
        rear = -1;
    }

    bool isFull() {
        return (rear + 1) % MAX_SIZE == front;
    }

    bool isEmpty() {
        return front == -1 && rear == -1;
    }

    void enqueue(int value) {
        if (isFull()) {
            std::cout << "Error: Queue is full!" << std::endl;
            return;
        }
        if (isEmpty()) {
            front = 0;
            rear = 0;
        } else {
            rear = (rear + 1) % MAX_SIZE;
        }
        arr[rear] = value;
        std::cout << value << " enqueued successfully." << std::endl;
    }

    void dequeue() {
        if (isEmpty()) {
            std::cout << "Error: Queue is empty!" << std::endl;
            return;
        }
        int dequeuedValue = arr[front];
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front = (front + 1) % MAX_SIZE;
        }
        std::cout << dequeuedValue << " dequeued successfully." << std::endl;
    }

    void peek() {
        if (isEmpty()) {
            std::cout << "Error: Queue is empty!" << std::endl;
            return;
        }
        std::cout << "Front element is: " << arr[front] << std::endl;
    }

    void display() {
        if (isEmpty()) {
            std::cout << "Queue is empty." << std::endl;
            return;
        }
        std::cout << "Queue elements are: ";
        int i = front;
        while (true) {
            std::cout << arr[i] << " ";
            if (i == rear) {
                break;
            }
            i = (i + 1) % MAX_SIZE;
        }
        std::cout << std::endl;
    }
};

int main() {
    Queue q;
    int choice, value;

    do {
        std::cout << "\n--- Queue Menu ---" << std::endl;
        std::cout << "1. Enqueue" << std::endl;
        std::cout << "2. Dequeue" << std::endl;
        std::cout << "3. Peek" << std::endl;
        std::cout << "4. Display" << std::endl;
        std::cout << "5. Check if Empty" << std::endl;
        std::cout << "6. Check if Full" << std::endl;
        std::cout << "0. Exit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter value to enqueue: ";
                std::cin >> value;
                q.enqueue(value);
                break;
            case 2:
                q.dequeue();
                break;
            case 3:
                q.peek();
                break;
            case 4:
                q.display();
                break;
            case 5:
                if (q.isEmpty()) {
                    std::cout << "Queue is empty." << std::endl;
                } else {
                    std::cout << "Queue is not empty." << std::endl;
                }
                break;
            case 6:
                if (q.isFull()) {
                    std::cout << "Queue is full." << std::endl;
                } else {
                    std::cout << "Queue is not full." << std::endl;
                }
                break;
            case 0:
                std::cout << "Exiting program. Goodbye!" << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }
    } while (choice != 0);

    return 0;
}