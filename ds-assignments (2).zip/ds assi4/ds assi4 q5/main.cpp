#include <iostream>
#include <queue>

class StackWithTwoQueues {
private:
    std::queue<int> q1;
    std::queue<int> q2;

public:
    void push(int x) {
        q1.push(x);
    }

    void pop() {
        if (q1.empty()) {
            std::cout << "Stack is empty. Cannot pop." << std::endl;
            return;
        }
        while (q1.size() > 1) {
            q2.push(q1.front());
            q1.pop();
        }
        q1.pop();
        std::swap(q1, q2);
    }

    int top() {
        if (q1.empty()) {
            std::cout << "Stack is empty. No top element." << std::endl;
            return -1;
        }
        int topElement;
        while (q1.size() > 1) {
            q2.push(q1.front());
            q1.pop();
        }
        topElement = q1.front();
        q2.push(q1.front());
        q1.pop();
        std::swap(q1, q2);
        return topElement;
    }

    bool empty() {
        return q1.empty();
    }
};

void runTwoQueueExample() {
    StackWithTwoQueues s;
    s.push(10);
    s.push(20);
    s.push(30);

    std::cout << "Top element is: " << s.top() << std::endl;
    s.pop();
    std::cout << "Top element after pop is: " << s.top() << std::endl;
    s.pop();
    std::cout << "Top element after second pop is: " << s.top() << std::endl;
    s.pop();
}