#include <iostream>
#include <string>
#include <queue>

void generateBinaryNumbers(int n) {
    if (n <= 0) {
        return;
    }

    std::queue<std::string> q;
    q.push("1");

    for (int i = 0; i < n; ++i) {
        std::string current = q.front();
        q.pop();
        std::cout << current << " ";

        std::string next1 = current + "0";
        std::string next2 = current + "1";

        q.push(next1);
        q.push(next2);
    }
    std::cout << std::endl;
}

int main() {
    int n = 10;
    std::cout << "Binary numbers from 1 to " << n << ":" << std::endl;
    generateBinaryNumbers(n);
    return 0;
}