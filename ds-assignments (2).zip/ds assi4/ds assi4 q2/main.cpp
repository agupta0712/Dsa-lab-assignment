#include <iostream>
#define MAX_SIZE 5

class CircularQueue {
private:
    int arr[MAX_SIZE];
    int front;
    int rear;

public:
    CircularQueue() {
        front = -1;
        rear = -1;
    }

    bool isEmpty() {
        return front == -1;
    }

    bool isFull() {
        return (rear + 1) % MAX_SIZE == front;
    }

    void enqueue(int value) {
        if (isFull()) {
            std::cout << "Error: Queue is full!" << std::endl;
            return;
        }
        if (isEmpty()) {
            front = 0;
        }
        rear = (rear + 1) % MAX_SIZE;
        arr[rear] = value;
        std::cout << "Enqueued: " << value << std::endl;
    }

    void dequeue() {
        if (isEmpty()) {
            std::cout << "Error: Queue is empty!" << std::endl;
            return;
        }
        int dequeuedValue = arr[front];
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front = (front + 1) % MAX_SIZE;
        }
        std::cout << "Dequeued: " << dequeuedValue << std::endl;
    }

    void peek() {
        if (isEmpty()) {
            std::cout << "Error: Queue is empty!" << std::endl;
            return;
        }
        std::cout << "Front element: " << arr[front] << std::endl;
    }

    void display() {
        if (isEmpty()) {
            std::cout << "Queue is empty." << std::endl;
            return;
        }
        std::cout << "Queue elements: ";
        int i = front;
        do {
            std::cout << arr[i] << " ";
            i = (i + 1) % MAX_SIZE;
        } while (i != (rear + 1) % MAX_SIZE);
        std::cout << std::endl;
    }
};

int main() {
    CircularQueue cq;
    int choice, value;

    do {
        std::cout << "\n--- Circular Queue Menu ---" << std::endl;
        std::cout << "1. Enqueue" << std::endl;
        std::cout << "2. Dequeue" << std::endl;
        std::cout << "3. Peek" << std::endl;
        std::cout << "4. Display" << std::endl;
        std::cout << "5. Check if Empty" << std::endl;
        std::cout << "6. Check if Full" << std::endl;
        std::cout << "0. Exit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter value to enqueue: ";
                std::cin >> value;
                cq.enqueue(value);
                break;
            case 2:
                cq.dequeue();
                break;
            case 3:
                cq.peek();
                break;
            case 4:
                cq.display();
                break;
            case 5:
                if (cq.isEmpty()) {
                    std::cout << "Queue is empty." << std::endl;
                } else {
                    std::cout << "Queue is not empty." << std::endl;
                }
                break;
            case 6:
                if (cq.isFull()) {
                    std::cout << "Queue is full." << std::endl;
                } else {
                    std::cout << "Queue is not full." << std::endl;
                }
                break;
            case 0:
                std::cout << "Exiting program. Goodbye!" << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }
    } while (choice != 0);

    return 0;
}