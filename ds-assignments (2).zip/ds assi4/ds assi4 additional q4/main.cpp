#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <numeric>

using namespace std;

int countStudents(vector<int>& students, vector<int>& sandwiches) {
    queue<int> studentQueue;
    for (int student : students) {
        studentQueue.push(student);
    }

    stack<int> sandwichStack;
    for (int i = sandwiches.size() - 1; i >= 0; --i) {
        sandwichStack.push(sandwiches[i]);
    }

    int rotations = 0;
    while (!studentQueue.empty() && rotations < studentQueue.size()) {
        if (studentQueue.front() == sandwichStack.top()) {
            studentQueue.pop();
            sandwichStack.pop();
            rotations = 0;
        } else {
            int student = studentQueue.front();
            studentQueue.pop();
            studentQueue.push(student);
            rotations++;
        }
    }

    return studentQueue.size();
}

int main() {
    vector<int> students = {1, 1, 0, 0};
    vector<int> sandwiches = {0, 1, 0, 1};

    cout << "Input: students = [1,1,0,0], sandwiches = [0,1,0,1]" << endl;
    cout << "Output: " << countStudents(students, sandwiches) << endl;

    return 0;
}