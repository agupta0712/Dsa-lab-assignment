#include <iostream>
#include <queue>
#include <algorithm>

int findMinIndex(std::queue<int>& q, int sortedIndex) {
    int min_val = -1;
    int min_index = -1;
    int size = q.size();
    
    for (int i = 0; i < size; ++i) {
        int current_val = q.front();
        q.pop();

        if (i < size - sortedIndex) {
            if (min_index == -1 || current_val < min_val) {
                min_val = current_val;
                min_index = i;
            }
        }
        q.push(current_val);
    }
    return min_index;
}

void insertInPlace(std::queue<int>& q, int min_val, int min_index) {
    int size = q.size();
    for (int i = 0; i < size; ++i) {
        int current_val = q.front();
        q.pop();

        if (i != min_index) {
            q.push(current_val);
        }
    }
    q.push(min_val);
}

void sortQueue(std::queue<int>& q) {
    if (q.empty()) {
        return;
    }

    int size = q.size();
    for (int i = 1; i <= size; ++i) {
        int min_index = findMinIndex(q, i - 1);
        int min_val = -1;
        
        for(int j = 0; j <= min_index; ++j) {
            int current = q.front();
            q.pop();
            if (j == min_index) {
                min_val = current;
            }
            q.push(current);
        }

        insertInPlace(q, min_val, min_index);
    }
}

void printQueue(std::queue<int> q) {
    while (!q.empty()) {
        std::cout << q.front() << " ";
        q.pop();
    }
    std::cout << std::endl;
}

int main() {
    std::queue<int> q;
    q.push(11);
    q.push(5);
    q.push(4);
    q.push(21);

    std::cout << "Original Queue: ";
    printQueue(q);

    sortQueue(q);

    std::cout << "Sorted Queue: ";
    printQueue(q);

    return 0;
}