#include <iostream>
#include <queue>
#include <stack>

bool canSortQueue(std::queue<int>& q) {
    std::stack<int> s;
    std::queue<int> sortedQueue;
    int expected = 1;

    while (!q.empty()) {
        if (q.front() == expected) {
            sortedQueue.push(q.front());
            q.pop();
            expected++;
        } else if (!s.empty() && s.top() == expected) {
            sortedQueue.push(s.top());
            s.pop();
            expected++;
        } else {
            s.push(q.front());
            q.pop();
        }
    }

    while (!s.empty()) {
        if (s.top() == expected) {
            sortedQueue.push(s.top());
            s.pop();
            expected++;
        } else {
            return false;
        }
    }

    return true;
}

void printQueue(std::queue<int> q) {
    while (!q.empty()) {
        std::cout << q.front() << " ";
        q.pop();
    }
    std::cout << std::endl;
}

int main() {
    std::queue<int> q;
    q.push(5);
    q.push(1);
    q.push(2);
    q.push(3);
    q.push(4);

    std::cout << "Original Queue: ";
    printQueue(q);

    if (canSortQueue(q)) {
        std::cout << "Output: Yes" << std::endl;
    } else {
        std::cout << "Output: No" << std::endl;
    }
    return 0;
}