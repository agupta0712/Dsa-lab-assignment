#include <iostream>
#include <string>
#include <queue>
#include <vector>

void findFirstNonRepeating(const std::string& str) {
    std::queue<char> q;
    std::vector<int> charCount(26, 0);

    for (char ch : str) {
        charCount[ch - 'a']++;

        if (charCount[ch - 'a'] == 1) {
            q.push(ch);
        }

        while (!q.empty() && charCount[q.front() - 'a'] > 1) {
            q.pop();
        }

        if (q.empty()) {
            std::cout << "-1 ";
        } else {
            std::cout << q.front() << " ";
        }
    }
    std::cout << std::endl;
}

int main() {
    std::string input = "a a b c";
    std::string cleanedInput;
    for (char ch : input) {
        if (ch != ' ') {
            cleanedInput += ch;
        }
    }

    std::cout << "Input: " << input << std::endl;
    std::cout << "Output: ";
    findFirstNonRepeating(cleanedInput);

    return 0;
}