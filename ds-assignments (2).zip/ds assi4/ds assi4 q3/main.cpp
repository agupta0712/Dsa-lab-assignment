#include <iostream>
#include <queue>
#include <stack>

void interleaveQueue(std::queue<int>& q) {
    if (q.empty() || q.size() % 2 != 0) {
        return;
    }

    int halfSize = q.size() / 2;
    std::stack<int> s;

    // Step 1: Push the first half of the queue to the stack
    for (int i = 0; i < halfSize; i++) {
        s.push(q.front());
        q.pop();
    }

    // Step 2: Enqueue elements from the stack back into the queue
    while (!s.empty()) {
        q.push(s.top());
        s.pop();
    }

    // Step 3: Dequeue the first half and enqueue to the end
    for (int i = 0; i < halfSize; i++) {
        q.push(q.front());
        q.pop();
    }

    // Step 4: Push the first half to stack again
    for (int i = 0; i < halfSize; i++) {
        s.push(q.front());
        q.pop();
    }

    // Step 5: Interleave elements from stack and queue
    while (!s.empty()) {
        q.push(s.top());
        s.pop();
        q.push(q.front());
        q.pop();
    }
}

void printQueue(std::queue<int> q) {
    while (!q.empty()) {
        std::cout << q.front() << " ";
        q.pop();
    }
    std::cout << std::endl;
}

int main() {
    std::queue<int> q;
    q.push(4);
    q.push(7);
    q.push(11);
    q.push(20);
    q.push(5);
    q.push(9);

    std::cout << "Original Queue: ";
    printQueue(q);

    interleaveQueue(q);

    std::cout << "Interleaved Queue: ";
    printQueue(q);

    return 0;
}