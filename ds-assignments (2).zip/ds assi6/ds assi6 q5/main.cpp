#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* right;
    Node* left;
    Node* up;
    Node* down;
    Node(int val) {
        data = val;
        right = left = up = down = NULL;
    }
};

Node* constructDoublyLinkedList(int mat[3][3], int n, int m) {
    Node* head = NULL;
    Node* prevRow[m];
    for (int i = 0; i < m; i++) prevRow[i] = NULL;
    for (int i = 0; i < n; i++) {
        Node* prev = NULL;
        for (int j = 0; j < m; j++) {
            Node* newNode = new Node(mat[i][j]);
            if (!head) head = newNode;
            if (prev) {
                prev->right = newNode;
                newNode->left = prev;
            }
            if (prevRow[j]) {
                prevRow[j]->down = newNode;
                newNode->up = prevRow[j];
            }
            prevRow[j] = newNode;
            prev = newNode;
        }
    }
    return head;
}

void display(Node* head, int n, int m) {
    Node* row = head;
    for (int i = 0; i < n; i++) {
        Node* col = row;
        for (int j = 0; j < m; j++) {
            cout << col->data << " ";
            col = col->right;
        }
        cout << endl;
        row = row->down;
    }
}

int main() {
    int mat[3][3] = {{1, 2, 3},
                     {4, 5, 6},
                     {7, 8, 9}};
    Node* head = constructDoublyLinkedList(mat, 3, 3);
    display(head, 3, 3);
    return 0;
}
