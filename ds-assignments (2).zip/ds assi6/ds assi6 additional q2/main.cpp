#include <iostream>
using namespace std;

struct DNode {
    int data;
    DNode* next;
    DNode* prev;
};

struct CNode {
    int data;
    CNode* next;
};

DNode* dhead = NULL;
CNode* chead = NULL;

void insertDoubly(int val) {
    DNode* newNode = new DNode();
    newNode->data = val;
    newNode->next = NULL;
    newNode->prev = NULL;
    if (!dhead) {
        dhead = newNode;
        return;
    }
    DNode* temp = dhead;
    while (temp->next) temp = temp->next;
    temp->next = newNode;
    newNode->prev = temp;
}

void insertCircular(int val) {
    CNode* newNode = new CNode();
    newNode->data = val;
    if (!chead) {
        chead = newNode;
        chead->next = chead;
        return;
    }
    CNode* temp = chead;
    while (temp->next != chead) temp = temp->next;
    temp->next = newNode;
    newNode->next = chead;
}

void removeEvenDoubly() {
    DNode* temp = dhead;
    while (temp) {
        if (temp->data % 2 == 0) {
            if (temp == dhead) {
                dhead = temp->next;
                if (dhead) dhead->prev = NULL;
                delete temp;
                temp = dhead;
            } else {
                DNode* prev = temp->prev;
                DNode* next = temp->next;
                prev->next = next;
                if (next) next->prev = prev;
                delete temp;
                temp = next;
            }
        } else temp = temp->next;
    }
}

void removeEvenCircular() {
    if (!chead) return;
    CNode *curr = chead, *prev = NULL;
    while (curr->next != chead) {
        if (curr->data % 2 == 0) {
            if (curr == chead) {
                CNode* last = chead;
                while (last->next != chead) last = last->next;
                chead = curr->next;
                last->next = chead;
                delete curr;
                curr = chead;
            } else {
                prev->next = curr->next;
                delete curr;
                curr = prev->next;
            }
        } else {
            prev = curr;
            curr = curr->next;
        }
    }
    if (curr->data % 2 == 0) {
        if (curr == chead) {
            delete curr;
            chead = NULL;
        } else prev->next = chead;
    }
}

void displayDoubly() {
    DNode* temp = dhead;
    while (temp) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

void displayCircular() {
    if (!chead) return;
    CNode* temp = chead;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != chead);
    cout << endl;
}

int main() {
    insertDoubly(1);
    insertDoubly(2);
    insertDoubly(3);
    insertDoubly(4);
    insertDoubly(5);
    insertCircular(6);
    insertCircular(7);
    insertCircular(8);
    insertCircular(9);
    insertCircular(10);
    removeEvenDoubly();
    removeEvenCircular();
    displayDoubly();
    displayCircular();
    return 0;
}
