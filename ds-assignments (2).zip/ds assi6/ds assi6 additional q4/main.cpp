#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prev;
    Node* random;
};

Node* head = NULL;

void insertEnd(int val) {
    Node* newNode = new Node();
    newNode->data = val;
    newNode->next = NULL;
    newNode->prev = NULL;
    newNode->random = NULL;
    if (!head) {
        head = newNode;
        return;
    }
    Node* temp = head;
    while (temp->next) temp = temp->next;
    temp->next = newNode;
    newNode->prev = temp;
}

void correctRandomPointer(Node* head) {
    if (!head) return;
    Node* temp = head;
    while (temp) {
        if (temp->random && temp->random->random == temp)
            temp->random = NULL;
        temp = temp->next;
    }
}

void display() {
    Node* temp = head;
    while (temp) {
        cout << temp->data;
        if (temp->random) cout << "(" << temp->random->data << ")";
        cout << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    insertEnd(1);
    insertEnd(2);
    insertEnd(3);
    insertEnd(4);
    head->random = head->next->next;
    head->next->next->random = head;
    correctRandomPointer(head);
    display();
    return 0;
}
