#include <iostream>
using namespace std;

struct DNode {
    int data;
    DNode* next;
    DNode* prev;
};

struct CNode {
    int data;
    CNode* next;
};

DNode* dhead = NULL;
CNode* chead = NULL;

void insertDoubly(int val) {
    DNode* newNode = new DNode();
    newNode->data = val;
    newNode->next = NULL;
    newNode->prev = NULL;
    if (!dhead) {
        dhead = newNode;
        return;
    }
    DNode* temp = dhead;
    while (temp->next) temp = temp->next;
    temp->next = newNode;
    newNode->prev = temp;
}

void insertCircular(int val) {
    CNode* newNode = new CNode();
    newNode->data = val;
    if (!chead) {
        chead = newNode;
        chead->next = chead;
        return;
    }
    CNode* temp = chead;
    while (temp->next != chead) temp = temp->next;
    temp->next = newNode;
    newNode->next = chead;
}

int sizeDoubly() {
    int count = 0;
    DNode* temp = dhead;
    while (temp) {
        count++;
        temp = temp->next;
    }
    return count;
}

int sizeCircular() {
    if (!chead) return 0;
    int count = 0;
    CNode* temp = chead;
    do {
        count++;
        temp = temp->next;
    } while (temp != chead);
    return count;
}

int main() {
    insertDoubly(10);
    insertDoubly(20);
    insertDoubly(30);
    insertCircular(5);
    insertCircular(15);
    insertCircular(25);
    cout << "Size of Doubly Linked List: " << sizeDoubly() << endl;
    cout << "Size of Circular Linked List: " << sizeCircular() << endl;
    return 0;
}
