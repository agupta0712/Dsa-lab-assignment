#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* head = NULL;
Node* head1 = NULL;
Node* head2 = NULL;

void insertEnd(int val) {
    Node* newNode = new Node();
    newNode->data = val;
    if (!head) {
        head = newNode;
        head->next = head;
        return;
    }
    Node* temp = head;
    while (temp->next != head) temp = temp->next;
    temp->next = newNode;
    newNode->next = head;
}

void splitList() {
    if (!head) return;
    Node *slow = head, *fast = head;
    while (fast->next != head && fast->next->next != head) {
        fast = fast->next->next;
        slow = slow->next;
    }
    if (fast->next->next == head) fast = fast->next;
    head1 = head;
    if (head->next != head) head2 = slow->next;
    fast->next = slow->next;
    slow->next = head;
}

void display(Node* headRef) {
    if (!headRef) return;
    Node* temp = headRef;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != headRef);
    cout << endl;
}

int main() {
    insertEnd(12);
    insertEnd(56);
    insertEnd(2);
    insertEnd(11);
    insertEnd(99);
    splitList();
    display(head1);
    display(head2);
    return 0;
}
