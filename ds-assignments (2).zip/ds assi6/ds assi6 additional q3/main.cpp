#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prev;
};

Node* head = NULL;

void insertEnd(int val) {
    Node* newNode = new Node();
    newNode->data = val;
    newNode->next = NULL;
    newNode->prev = NULL;
    if (!head) {
        head = newNode;
        return;
    }
    Node* temp = head;
    while (temp->next) temp = temp->next;
    temp->next = newNode;
    newNode->prev = temp;
}

Node* reverseInGroups(Node* head, int k) {
    Node* current = head;
    Node* next = NULL;
    Node* newHead = NULL;
    int count = 0;
    while (current && count < k) {
        next = current->next;
        current->next = current->prev;
        current->prev = next;
        newHead = current;
        current = next;
        count++;
    }
    if (next) {
        Node* rest = reverseInGroups(next, k);
        head->next = rest;
        if (rest) rest->prev = head;
    }
    return newHead;
}

void display() {
    Node* temp = head;
    while (temp) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    insertEnd(1);
    insertEnd(2);
    insertEnd(3);
    insertEnd(4);
    insertEnd(5);
    insertEnd(6);
    insertEnd(7);
    insertEnd(8);
    int k = 3;
    head = reverseInGroups(head, k);
    display();
    return 0;
}
